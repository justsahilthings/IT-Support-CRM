import React from 'react';
import { getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type Auth,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const GOOGLE_DRIVE_SCOPES = ['https://www.googleapis.com/auth/drive'] as const;

let firebaseApp: FirebaseApp | null = null;
let firebaseAuth: Auth | null = null;
let authListenerAttached = false;

// Strictly in-memory token storage (never persisted to localStorage, sessionStorage, or SQLite)
let inMemoryDriveAccessToken: string | null = null;
let inMemoryDriveUserEmail: string | null = null;

export function initGoogleDriveAuth(): Auth {
  if (!firebaseApp) {
    firebaseApp = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
  }
  if (!firebaseAuth) {
    firebaseAuth = getAuth(firebaseApp);
  }
  if (!authListenerAttached) {
    authListenerAttached = true;
    onAuthStateChanged(firebaseAuth, (fbUser) => {
      if (!fbUser) {
        inMemoryDriveAccessToken = null;
        inMemoryDriveUserEmail = null;
      } else if (fbUser.email) {
        inMemoryDriveUserEmail = fbUser.email;
      }
    });
  }
  return firebaseAuth;
}

export async function signInWithGoogleDrive(): Promise<{
  accessToken: string;
  email: string | null;
  displayName: string | null;
}> {
  const auth = initGoogleDriveAuth();
  const provider = new GoogleAuthProvider();
  for (const scope of GOOGLE_DRIVE_SCOPES) {
    provider.addScope(scope);
  }
  provider.setCustomParameters({
    prompt: 'consent select_account',
  });

  const result = await signInWithPopup(auth, provider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  const token =
    credential?.accessToken ||
    (result as unknown as { _tokenResponse?: { oauthAccessToken?: string } })?._tokenResponse?.oauthAccessToken ||
    null;

  if (!token) {
    throw new Error('Google sign-in succeeded, but no Google Drive OAuth access token was returned.');
  }

  inMemoryDriveAccessToken = token;
  inMemoryDriveUserEmail = result.user?.email || null;

  return {
    accessToken: token,
    email: result.user?.email || null,
    displayName: result.user?.displayName || null,
  };
}

export function getInMemoryDriveAccessToken(): string | null {
  return inMemoryDriveAccessToken;
}

export function getInMemoryDriveUserEmail(): string | null {
  return inMemoryDriveUserEmail;
}

export async function clearInMemoryDriveAuth(): Promise<void> {
  inMemoryDriveAccessToken = null;
  inMemoryDriveUserEmail = null;
  try {
    const auth = initGoogleDriveAuth();
    await signOut(auth);
  } catch {
    // ignore sign-out error
  }
}

export function GoogleSignInButton({
  onClick,
  disabled,
  label = 'Sign in with Google Drive',
}: {
  onClick: () => void;
  disabled?: boolean;
  label?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="inline-flex items-center gap-2.5 h-10 px-4 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-900 shadow-xs text-xs font-semibold tracking-tight disabled:opacity-50 cursor-pointer whitespace-nowrap"
    >
      <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48" aria-hidden="true">
        <path
          fill="#EA4335"
          d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
        />
        <path
          fill="#4285F4"
          d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
        />
        <path
          fill="#FBBC05"
          d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
        />
        <path
          fill="#34A853"
          d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
        />
      </svg>
      <span>{label}</span>
    </button>
  );
}
